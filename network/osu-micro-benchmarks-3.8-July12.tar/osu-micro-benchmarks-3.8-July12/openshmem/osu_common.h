#ifndef _OSU_COMMON_H_
#define _OSU_COMMON_H_

#define TIME() getMicrosecondTimeStamp()
int64_t getMicrosecondTimeStamp();

#endif /* _OSU_COMMON_H */
